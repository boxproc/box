import ProductLimitsFeesCommissions from './ProductLimitsFeesCommissions';

export default ProductLimitsFeesCommissions;
