import ProductAprs from './ProductAprs';

export default ProductAprs;
