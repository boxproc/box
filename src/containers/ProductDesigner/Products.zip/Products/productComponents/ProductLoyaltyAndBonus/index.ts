import ProductLoyaltyAndBonus from './ProductLoyaltyAndBonus';

export default ProductLoyaltyAndBonus;
