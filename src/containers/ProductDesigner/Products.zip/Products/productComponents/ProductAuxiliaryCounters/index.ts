import ProductAuxiliaryCounters from './ProductAuxiliaryCounters';

export default ProductAuxiliaryCounters;
