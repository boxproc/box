import ProductLoyaltyAndBonusForm from './ProductLoyaltyAndBonusForm';

export default ProductLoyaltyAndBonusForm;
