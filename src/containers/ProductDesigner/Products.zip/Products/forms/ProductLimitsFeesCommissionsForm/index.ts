import ProductLimitsFeesCommissionsForm from './ProductLimitsFeesCommissionsForm';

export default ProductLimitsFeesCommissionsForm;
